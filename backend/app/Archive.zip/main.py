# backend/app/main.py
from fastapi import FastAPI

from .api.api import api_router
from .api.endpoints import user, channel, plan # Import all routers

app = FastAPI(
    title="MemberFlow API",
    description="The backend API for the MemberFlow Telegram subscription bot.",
    version="0.1.0"
)

app.include_router(api_router)
# Include all routers
app.include_router(user.router, prefix="/users", tags=["users"])
app.include_router(channel.router, prefix="/channels", tags=["channels"])
app.include_router(plan.router, prefix="/plans", tags=["plans"])

@app.get("/")
def read_root():
    return {"status": "ok"}