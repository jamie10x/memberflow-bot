# backend/app/api/endpoints/channel.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ... import crud
from ...schemas import channel as channel_schema
from .. import deps

router = APIRouter()

@router.post("/", response_model=channel_schema.Channel)
def create_channel( # Simplified name
        channel_in: channel_schema.ChannelCreate,
        db: Session = Depends(deps.get_db)
):
    return crud.crud_channel.create_user_channel(db=db, channel=channel_in, user_id=channel_in.user_id)

@router.get("/", response_model=list[channel_schema.Channel])
def read_user_channels(
        user_id: int,
        db: Session = Depends(deps.get_db)
):
    """
    Get all channels for a specific user.
    """
    return crud.crud_channel.get_user_channels(db=db, user_id=user_id)