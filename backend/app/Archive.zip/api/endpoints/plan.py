# backend/app/api/endpoints/plan.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ... import crud
from ...schemas import plan as plan_schema
from .. import deps

router = APIRouter()

@router.post("/", response_model=plan_schema.Plan)
def create_plan_for_user(
        user_id: int,
        plan_in: plan_schema.PlanCreate,
        db: Session = Depends(deps.get_db)
):
    """
    Create a new plan for a user.
    Example: POST /users/1/plans/
    """
    return crud.crud_plan.create_user_plan(db=db, plan=plan_in, user_id=user_id)

@router.get("/", response_model=list[plan_schema.Plan])
def read_user_plans(
        user_id: int,
        db: Session = Depends(deps.get_db)
):
    """
    Get all plans for a specific user.
    """
    return crud.crud_plan.get_user_plans(db=db, user_id=user_id)