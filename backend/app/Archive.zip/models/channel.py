# backend/app/models/channel.py
from sqlalchemy import Column, Integer, String, BigInteger, ForeignKey
from sqlalchemy.orm import relationship

from ..core.database import Base

class Channel(Base):
    __tablename__ = "channels"

    id = Column(Integer, primary_key=True, index=True)
    telegram_channel_id = Column(BigInteger, unique=True, index=True, nullable=False)
    title = Column(String, nullable=False)

    # Foreign key to link with the User model
    user_id = Column(Integer, ForeignKey("users.id"))

    # SQLAlchemy relationship to easily access the owner user
    owner = relationship("User", back_populates="channels")