# backend/app/models/user.py
from sqlalchemy import Column, Integer, BigInteger, DateTime, String
from sqlalchemy.orm import relationship # <-- Add this import
from sqlalchemy.sql import func
from ..core.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(BigInteger, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Add these two lines for the back-reference
    channels = relationship("Channel", back_populates="owner")
    plans = relationship("Plan", back_populates="owner")